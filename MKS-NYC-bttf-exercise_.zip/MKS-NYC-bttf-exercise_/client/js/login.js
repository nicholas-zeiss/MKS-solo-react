


var LoginAPI = (function() {



  function loginToServer() {
    $("#loginBox").show();
    $("#loginBtn").on("click",function(){
      var username = $("#loginUsername").val();
      var password = $("#loginPassword").val();
      var userInfo = {
        username: username,
        password: password
      };
      return ServerAPI.login(userInfo);
    });
  };

  function createLogout() {





  }

  return {
    loginToServer: loginToServer
  }


  })();
